import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserDataService } from '../../services/user-data.service';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrl: './add-employee.component.css'
})
export class AddEmployeeComponent {
  employeeForm: FormGroup 
  constructor(private fb: FormBuilder, private http:UserDataService) {
    this.employeeForm = this.fb.group({
      fullName: ['', Validators.required],
      nickname: ['', [Validators.required, Validators.pattern('^[a-zA-Z]+$')]],
      dateOfJoining: ['', [Validators.required, this.validateDateOfJoining]],
      dateOfBirth: ['', [Validators.required, this.validateDateOfBirth]],
      designation: ['', Validators.required],
      salary: ['', [Validators.required, Validators.min(0.01)]],
      photo: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      mobile: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      graduationYear: ['', [Validators.required, Validators.min(1924), Validators.max(new Date().getFullYear())]],
    });
  }

  validateDateOfJoining(control: any) {
    const date = new Date(control.value);
    const currentYear = new Date().getFullYear();
    if (date.getFullYear() < 2000 || date.getFullYear() > currentYear) {
      return { invalidDateOfJoining: true };
    }
    return null;
  }

  validateDateOfBirth(control: any) {
    const date = new Date(control.value);
    const currentYear = new Date().getFullYear();
    if (date.getFullYear() < currentYear - 100 || date.getFullYear() > currentYear) {
      return { invalidDateOfBirth: true };
    }
    return null;
  }
  
  onSubmit() {

    if (this.employeeForm.valid) {

      
      // console.log('Employee data:', this.employeeForm.value);
     this.http.saveUsers(this.employeeForm.value).subscribe((res)=>{
        console.log(res)

      })
    }
  }

}