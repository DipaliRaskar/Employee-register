// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-edit-users',
//   templateUrl: './edit-users.component.html',
//   styleUrl: './edit-users.component.css'
// })
// export class EditUsersComponent {

// }

import { Component ,OnInit} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserDataService } from '../../services/user-data.service';
import { ActivatedRoute, Router } from '@angular/router';

 @Component({
    selector: 'app-edit-users',
    templateUrl: './edit-users.component.html',
    styleUrl: './edit-users.component.css'
  })
export class EditUsersComponent  implements OnInit{
  employeeForm!: FormGroup 
   resumeForm: any;
  constructor(private fb: FormBuilder, private http:UserDataService,private route:ActivatedRoute,private router:Router) {
  }

  User:any;

  ngOnInit(): void {
   
    let id = this.route.snapshot.paramMap.get('id')
    this.http.getSingle(id).subscribe((res)=>{
      this.employeeForm.patchValue(res)
    })
    
    this.employeeForm = this.fb.group({
      id: ['', Validators.required],
      fullName: ['', Validators.required],
      nickname: ['', [Validators.required, Validators.pattern('^[a-zA-Z]+$')]],
      dateOfJoining: ['', [Validators.required, this.validateDateOfJoining]],
      dateOfBirth: ['', [Validators.required, this.validateDateOfBirth]],
      designation: ['', Validators.required],
      salary: ['', [Validators.required, Validators.min(0.01)]],
      photo: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      mobile: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      graduationYear: ['', [Validators.required, Validators.min(1924), Validators.max(new Date().getFullYear())]],
    });
  }


  validateDateOfJoining(control: any) {
    const date = new Date(control.value);
    const currentYear = new Date().getFullYear();
    if (date.getFullYear() < 2000 || date.getFullYear() > currentYear) {
      return { invalidDateOfJoining: true };
    }
    return null;
  }

  validateDateOfBirth(control: any) {
    const date = new Date(control.value);
    const currentYear = new Date().getFullYear();
    if (date.getFullYear() < currentYear - 100 || date.getFullYear() > currentYear) {
      return { invalidDateOfBirth: true };
    }
    return null;
  }

  onSubmit() {
    this.http.editUser(this.resumeForm.value).subscribe(()=>{
      console.log(this.resumeForm.value);
      // this.router.navigate(['/List-view'])
    })
  }
}
