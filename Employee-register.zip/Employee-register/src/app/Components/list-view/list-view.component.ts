import { Component } from '@angular/core';
import { UserDataService } from '../../services/user-data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-view',
  templateUrl: './list-view.component.html',
  styleUrl: './list-view.component.css',
})
export class ListViewComponent {
  // a:any
  // b:any
  deleteSMS: undefined | string;

  users: any;
  sortBy: any = 'DoB';

  sortOption: string = 'doj';

  constructor(private userdata: UserDataService, private router: Router) {
    this.userlist();
  }

  deleteUser(id: number) {
    console.log('test id', id);
    this.userdata.deleteUsers(id).subscribe((res) => {
      if (res) {
        this.deleteSMS = 'User is Deleted';

        this.userdata.users().subscribe((data) => {
          console.log(data);
          this.users = data;
        });
      }
    });

    setTimeout(() => {
      this.deleteSMS = undefined;
    }, 300);
  }

  userlist() {
    this.userdata.users().subscribe((data) => {
      console.log(data);
      this.users = data;
      this.sortEmployList();
    });
  }

  edit(data: any) {
    this.router.navigate(['edit/' + data.id]);
  }


  onSortChange(event: any) {
    this.sortOption = event.target.value; // Capture the selected value
    this.sortEmployList(); // Call the sorting function
  }
  
  sortEmployList() {
    switch (this.sortOption) {
      // case 'name':
      //   this.users.sort((a: { fullName: string; }, b: { fullName: string; }) => 
      //     a.fullName.localeCompare(b.fullName)
      //   );
      //   break;
        
      case 'doj':
        this.users.sort(
          (a: { dateOfJoining: string | number | Date }, b: { dateOfJoining: string | number | Date }) =>
            new Date(a.dateOfJoining).getTime() - new Date(b.dateOfJoining).getTime()
        );
        break;
  
      case 'dob':
        this.users.sort(
          (a: { dateOfBirth: string | number | Date }, b: { dateOfBirth: string | number | Date }) =>
            new Date(a.dateOfBirth).getTime() - new Date(b.dateOfBirth).getTime()
        );
        break;
  
      default:
        break;
    }
  }
}
