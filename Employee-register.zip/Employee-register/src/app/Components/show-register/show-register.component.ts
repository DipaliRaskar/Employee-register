import { Component } from '@angular/core';
import { UserDataService } from '../../services/user-data.service';

@Component({
  selector: 'app-show-register',
  templateUrl: './show-register.component.html',
  styleUrl: './show-register.component.css'
})
export class ShowRegisterComponent {
  users: any;
  constructor(private userdata:UserDataService){
 userdata.users().subscribe((data)=>{
  console.log(data)
  this.users=data
 } 
 
 );
  }
}
