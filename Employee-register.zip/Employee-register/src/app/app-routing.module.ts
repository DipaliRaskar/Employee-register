import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddEmployeeComponent } from './Components/add-employee/add-employee.component';
import { ShowRegisterComponent } from './Components/show-register/show-register.component';
import { ListViewComponent } from './Components/list-view/list-view.component';
import { EditUsersComponent } from './Components/edit-users/edit-users.component';

const routes: Routes = [
  {path:"ADD",component:AddEmployeeComponent},
  {path:"SHOW",component:ShowRegisterComponent},
  {path:"List-view",component:ListViewComponent},
  {path:"edit/:id",component:EditUsersComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
